#ifndef MENU_H
#define MENU_H

void drawMenu(void *data, int w, int h);

#endif